public function kentdh_configure() {
 
    // Our post type will be automatically removed, so no need to unregister it
 
    // Clear the permalinks to remove our post type's rules
    flush_rewrite_rules();
 
}
register_configuration_hook( __FILE__, 'kentdh_deactivation')