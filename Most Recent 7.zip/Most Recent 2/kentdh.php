<?php
/*
Plugin Name: KentDH
Plug URI: HTTP://kentdhblog.wordpress.com 
Description: The KentDH plugin is designed for Digital Humanities staff and students 
at the University of Kent to use to contact each other and find out information about the
faculty.
Author: Glen Learmond, Ernest Amoako, Jason D'Silva 
Version: 1.0
Author URI: http.//kentdhblog.wordpress.com
*/
// Kent DH Add Researcher
 
function register_cpt_Kent_DH() {
 
    $labels = array(
        'name' => _x( 'Kent DH', 'kent_dh' ),
        'singular_name' => _x( 'Kent DH', 'kent_dh' ),
        'add_new' => _x( 'Add New', 'DH_researcher' ),
        'add_new_item' => _x( 'Add New Researcher', 'kent_dh' ),
        'edit_item' => _x( 'Edit Kent Researcher', 'kent_dh' ),
        'new_item' => _x( 'New Kent Researcher', 'kent_dh' ),
        'view_item' => _x( 'View Kent Researcher', 'kent_dh' ),
        'search_items' => _x( 'Search Kent Researcher', 'kent_dh' ),
        'not_found' => _x( 'No Kent Researchers found', 'kent_dh' ),
        'not_found_in_trash' => _x( 'No tags found in Trash', 'kent_dh' ),
        'parent_item_colon' => _x( 'Parent DH Researcher:', 'kent_dh' ),
        'menu_name' => _x( 'DH Researcher', 'kent_dh' ),
    );
 
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'Researcher filterable by Tag',
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'page-attributes' ),
        'taxonomies' => array( 'tags' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-format-audio',
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );
 
    register_post_type( 'kent_dh', $args );
}
 
add_action( 'init', 'register_cpt_kent_dh' );

function genres_taxonomy() {
    register_taxonomy(
        'tags',
        'DH_researcher',
        array(
            'hierarchical' => true,
            'label' => 'tags',
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'genre',
                'with_front' => false
            )
        )
    );
}
add_action( 'init', 'genres_taxonomy');

// Function used to automatically creates a page.
function create_dh_researcher_pages()
  {
   //post status and options
    $post = array(
          'comment_status' => 'open',
          'ping_status' =>  'closed' ,
          'post_date' => date('Y-m-d H:i:s'),
          'post_name' => 'kent_dh',
          'post_status' => 'publish' ,
          'post_title' => 'Kent Researcher',
          'post_type' => 'page',
    );
    //insert page and save the id
    $newvalue = wp_insert_post( $post, false );
    //save the id in the database
    update_option( 'mrpage', $newvalue );
  }

  // // Activates function if plugin is activated
register_activation_hook( __FILE__, 'create_dh_researcher_pages');



?>