



public function _construct($ file) {
	parent::_construct( $file);
	$this->rules();
}


public function activation() {
	/*This method activates the plugin and intalises the database./* 
}

public function deactivation() {
	/*This particular method runs whenever the plugin is deactivated./*
}

public function loaded() {
	/*The method is called each time the page is reloaded./* 
}

public function preferences() {
	/*This method is called when the plugin is fully functioning./*  
}

GLOBALS ['KentDH'] = new KentDH();

