public function activation (){
function pluginprefix_setup_post_type() {
 
    // Register our "book" custom post type
    register_post_type( 'book', array( 'public' => 'true' ) );
 
}
add_action( 'init', 'pluginprefix_setup_post_type' );
 
function pluginprefix_install() {
 
    // Trigger our function that registers the custom post type
    pluginprefix_setup_post_types();
 
    // Clear the permalinks after the post type has been registered
    flush_rewrite_rules();
 }
}
register_activation_hook( kent DH, 'pluginprefix_install' );