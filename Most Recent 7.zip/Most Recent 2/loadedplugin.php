
/* 




public function activation() {
	/*This method activates the plugin and intalises the database./* 
}

public function deactivation() {
	/*This particular method runs whenever the plugin is deactivated./*
}

public function loaded() {
	/*The method is called each time the page is reloaded./*
}


GLOBALS ['KentDH'] = new KentDH();


